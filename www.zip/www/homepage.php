<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All record</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=ABeeZee">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Actor">
    <link rel="stylesheet" href="assets/css/Login-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Profile-Edit-Form.css">
    <link rel="stylesheet" href="assets/css/Profile-Edit-Form.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body style="background-position:center;background-size:cover;background-repeat:no-repeat;background-image:url(&quot;assets/img/BG-01.png&quot;);height:100vh;">
    <div style="margin-top:130px;">
        <div class="container">
            <div class="row">
                <div class="col-md-4" id="hover">
                    <a href="insert.php"><div class="jumbotron" style="background-color:rgba(101,145,190,0.1);">
                        <h1 class="text-center" style="color:rgb(255,255,255);font-family:Actor, sans-serif;">Student Information</h1>
                       
                    </div></a>
                </div>
                <div class="col-md-4">
                    <a href="record.php"><div class="jumbotron" style="background-color:rgba(101,145,190,0.1);">
                        <h1 class="text-center" style="color:rgb(255,255,255);font-family:Actor, sans-serif;">Find Student Record</h1>
                        <p></p>
                    </div></a>
                </div>
                <div class="col-md-4">
                    <a href="checkoption.php"><div class="jumbotron" style="background-color:rgba(101,145,190,0.07);">
                        <h1 class="text-center" style="color:rgb(255,255,255);font-family:Actor, sans-serif;">Edit &nbsp;Student Record</h1>
                    </div></a>
                </div>
            </div>
        </div>
    </div>
	<br />
	<br />
	<br />
	<br />
	<div class="container"><a href="index.php" class="btn btn-danger">Log Out</a></div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/MUSA_fullscreen-search.js"></script>
    <script src="assets/js/Profile-Edit-Form.js"></script>
</body>

</html>