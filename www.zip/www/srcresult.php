<!DOCTYPE html>
<html lang="en">
<head>
  <title>Management Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bs4/bootstrap.min.css">
  <script src="bs4/jquery.min.js"></script>
  <script src="bs4/popper.min.js"></script>
  <script src="bs4/bootstrap.min.js"></script>
  <link rel="stylesheet" href="common.css" />
  <script src="sweetalert2/sweetalert2.min.js"></script>
	<link rel="stylesheet" type="text/css" href="sweetalert2/sweetalert2.css">
</head>
<body>

<div class="jumbotron text-center headd" style="height:180px;">
  <h1>Your Searchin Result Here.....</h1>
	<a href="insert.php"><input type="subbmit" class="btn btn-primary" style="left:0px;" value="back" /></a>
	<a href="homepage.php"><input type="subbmit" class="btn btn-info" style="left:0px;" value="Home" /></a>
</div>

<div class="container">

<div class="row">
	<div class="col-md-2"></div>
	<div class="col-md-6 details">
	
		<?php
			$db= new SQLite3('management.db');
			$sid=$_POST['roll'];
			
			$sql="select * from studentinfo where broll='$sid'";
			$result=$db->query($sql);
			$number=count($result);
			if($number == 0)
			{
				
				echo "empty....";
			}
			else
			{
			
			$row=$result->fetchArray(SQLITE3_ASSOC);
			
			$fname=$row['fname'];
			$lname=$row['lname'];
			$fullname=$fname." ".$lname;
			$collegename=$row['collegename'];
			$smobile=$row['smobile'];
			$Gmobile=$row['gmobile'];
			$battch=$row['battch'];
			$broll=$row['broll'];
			$image=$row['image'];
		?>
		<div class="container dkp">
			<div class="dkpleft">
				<img src="studentimage/<?php echo $image;?>" alt="user Imge" style="height:200px;width:180px;border-radius:20px;"/>
			</div>
			
			<div class="dkpright">
				<pre style="color:white;">        Name:  <?php echo $fullname?></pre>
				<pre style="color:white;"> CollegeName:  <?php echo $collegename?></pre>
				<pre style="color:white;"> Student_Mob:  <?php echo $smobile?></pre>
				<pre style="color:white;"> Gardian_Mob:  <?php echo $Gmobile?></pre>
				<pre style="color:white;">       Bathc:  <?php echo $battch?></pre>
				<pre style="color:white;">       Broll:  <?php echo $broll?></pre>
				<pre style="color:red;"> .........</pre>
		
			</div>
			
		</div>
		
	</div>
	
			<?php }?>
		
	<div class="col-md-2">
		<form action="delete.php" method="post">
			<input type="hidden" value="<?php echo $broll;?>" name="roll" />
			<input type="submit" class="btn btn-warning" style="color:red;font-weight:bold;" name="dltnow" value="Delete parmanently" />
		</form>
	</div>

</div>
</div>
 
</body>
</html>
