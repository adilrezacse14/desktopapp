<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<script src="sweetalert2/sweetalert2.min.js"></script>
	<link rel="stylesheet" type="text/css" href="sweetalert2/sweetalert2.css">
	<title></title>
</head>
<body>
	
</body>
</html>

<?php
	$db= new SQLite3('management.db');
	if(isset($_POST["dltnow"]))
	{
		$roll=$_POST['roll'];
		
		$sql="DELETE FROM `studentinfo` WHERE `studentinfo`.`broll` = '$roll'";
		$result=$db->query($sql);
		$sql="DELETE FROM `student_marks` WHERE `student_marks`.`roll` = '$roll'";
		$result=$db->query($sql);
		
		$sql="DELETE FROM `student_exam_marks` WHERE `student_exam_marks`.`roll` = '$roll'";
		$result=$db->query($sql);
		
		
		if($result)
		{
			echo "<script language='javascript'>
					
					swal(
				  'Deleted',
				  'Student Parmanently deleted',
				  'success'
				);
					
				</script>";
				
			echo "<script language='javascript'>
			setTimeout(function(){
					window.location.href = 'insert.php';}, 2000);
			</script>";
		}
		else
		{
			echo "<script language='javascript'>
					
					swal(
				  'Sorry!!!',
				  'Admin Not RecogNised....',
				  'error'
				);
					
				</script>";
		}
		
		
	}

?>