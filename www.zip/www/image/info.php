<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Untitled</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=ABeeZee">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Actor">
    <link rel="stylesheet" href="assets/css/Login-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Profile-Edit-Form.css">
    <link rel="stylesheet" href="assets/css/Profile-Edit-Form.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body style="background-position:center;background-size:cover;background-repeat:no-repeat;background-image:url(&quot;assets/img/BG-01.png&quot;);">
    <h1 class="text-center" style="margin-top:60px;color:rgb(254,255,255);font-family:Actor, sans-serif;">Student Information</h1>
    <div style="margin-top:100px;">
        <div class="container">
            <div class="row justify-content-center align-items-center">
                <div class="col-md-4 align-self-center"><img class="rounded-circle img-fluid" src="assets/img/Asian_Male_Confused.gif" width="250px" height="100" id="image"></div>
                <div class="col-md-4"> <table>
     <tr class="tbd">
    <td>Name</td>
    <td>ABCD</td>
        
  </tr>
     <tr class="tbd">
    <td>Roll</td>
    <td>140014</td>
     
  </tr>
     <tr class="tbd">
    <td>Department</td>
    <td>CSE</td>
     
  </tr>
    
     <tr class="tbd">
         <td>Institution</td>
         <td>RUET</td>
  </tr>
     <tr class="tbd">
    <td>CGPA</td>
    <td>2.50</td>
  </tr>
     
</table></div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/MUSA_fullscreen-search.js"></script>
    <script src="assets/js/Profile-Edit-Form.js"></script>
</body>

</html>