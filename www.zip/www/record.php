<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Untitled</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=ABeeZee">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Actor">
    <link rel="stylesheet" href="assets/css/Login-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Profile-Edit-Form.css">
    <link rel="stylesheet" href="assets/css/Profile-Edit-Form.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body style="background-position:center;background-size:cover;background-repeat:no-repeat;background-image:url(&quot;assets/img/BG-01.png&quot;);height:100vh;">
<a href="homepage.php"><button class="btn btn-primary">back to home</button></a>  <a href="examrecord.php"><button class="btn btn-info">Exam_record</button></a>
    <h1 class="text-center" style="margin-top:60px;color:rgb(254,255,255);font-family:Actor, sans-serif;">Find Student Record</h1>
	<div class="container">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6">
				<form action="record.php" method="post">
					<input type="text" name="roll" class="form-control" placeholder="student Roll please..." />
					<br />
					<input name="finder" type="submit" class="form-control btn btn-info" />
				</form>
			</div>
			<div class="col-md-3"></div>
			
		</div>
	</div>
	
    <div style="margin-top:100px;">
        <div class="container">
            <div class="row">
                <div class="col-md-12"><table>
  <tr>
    <th>Roll</th>
    <th>Exam_NO</th>
    <th>Proposal date</th>
    <th>Submission date</th>
    <th>AssignMent_marks</th>
    <th>Highest</th>
     
  </tr>
  
  <?php
	
	$connection=new SQLite3('management.db');
	
	if(isset($_POST['finder']))
	{
		$roll=$_POST['roll'];
		$sql="select * from student_marks where roll='$roll' ORDER BY id DESC";
		$result=$connection->query($sql);
		while($row=$result->fetchArray(SQLITE3_ASSOC))
			{
			$roll=$row['roll'];
			$questoionno=$row['questoionno'];
			$date=$row['date'];
			$subdate=$row['subdate'];
			$ass_marks=$row['ass_marks'];
			
			$sql="select MAX(ass_marks) as maxi from student_marks where questoionno='$questoionno' ORDER BY id DESC";
			$result44=$connection->query($sql);
			$row3=$result44->fetchArray(SQLITE3_ASSOC);
			$row4=$row3['maxi'];
			
?>
 
  <tr>
    <td><?php echo $roll; ?></td>
    <td><?php echo $questoionno; ?></td>
    <td><?php echo $date; ?></td>
    <td><?php echo $subdate; ?></td>
    <td><?php echo $ass_marks; ?></td>
    <td><?php echo $row4; ?></td>
    
  </tr>

		<?php } ?>
	
<?php } ?>
  
</table></div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/MUSA_fullscreen-search.js"></script>
    <script src="assets/js/Profile-Edit-Form.js"></script>
</body>

</html>


