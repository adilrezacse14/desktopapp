<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Untitled</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=ABeeZee">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Actor">
    <link rel="stylesheet" href="assets/css/Login-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Profile-Edit-Form.css">
    <link rel="stylesheet" href="assets/css/Profile-Edit-Form.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body style="background-position:center;background-size:cover;background-repeat:no-repeat;background-image:url(&quot;assets/img/BG-01.png&quot;);height:100vh;">
<a href="homepage.php"><button class="btn btn-danger">back to home</button></a>
    <h1 class="text-center" id="reco" style="margin-top:60px;color:green;font-family:Actor, sans-serif;">Exam Marks</h1>
    <div style="margin-top:73px;">
        <div class="container">
		<form action="mark.php" method="post">
            <div class="row">
                <div class="col-md-4 col-lg-2"><form id="record">
             <div class="form-group">
                            <label style="color:white;">Roll</label>
                            <input class="form-control" type="text" placeholder="a1234" required name="roll">
                        </div>
    
     <div class="form-group">
	 <label style="color:white;">Exam Number</label>
	 <select name="questoionno" class="form-control" required>

                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
         
         
         </select>
    </div>
    
     <div class="form-group">
                            <label style="color:white;">Exam Date</label>
                            <input class="form-control" type="date" required name="date">
                        </div>
                    </form></div>
                <div class="col-md-4 col-lg-3"></div>
                <div class="col-md-4 col-lg-7"><div class="col-md-8">
<div class="form-group">
                <label style="color:white;">Exam Marks</label>
               <input class="form-control" type="text" placeholder="100" required name="exam_marks">
</div>
    </div>

<div class="col-md-8">
<div class="form-group">
                <label style="color:white;">Assignment Marks</label>
               <input class="form-control" type="text" placeholder="100" required  name="ass_marks">
</div>
    </div>

<div class="col-md-8" style="margin-top:50px;">
    <input name="subbtttt" type="submit" value="Record This Data" class="btn btn-primary btn-block btn-lg"/>
</div></div>
            </div>
			
		</form>
        </div>
    </div>
	
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/MUSA_fullscreen-search.js"></script>
    <script src="assets/js/Profile-Edit-Form.js"></script>
</body>

</html>


<?php

	
	$connection=new SQLite3('management.db');
	
	if(isset($_POST['subbtttt']))
	{
		$roll=$_POST['roll'];
		$questoionno=$_POST['questoionno'];
		$date=$_POST['date'];
		$exam_marks=$_POST['exam_marks'];
		$ass_marks=$_POST['ass_marks'];
		
		
		$sql="select * from studentinfo where broll=='$roll'";
		$resflag=$connection->query($sql);
		if($resflag)
		{
			$sql="insert into student_marks(roll,questoionno,date,exam_marks,ass_marks)values('$roll','$questoionno','$date','$exam_marks','$ass_marks')";
			$result=$connection->query($sql);
			
			if($result)
			{
				echo "<script type='text/javascript'>
					document.getElementById('reco').innerHTML='Record Inserted successfully!!'
				</script>";
			}
			
		}
		else
		{
			echo "<script type='text/javascript'>
					document.getElementById('reco').innerHTML='This roll is not recorded!!!!..'
				</script>";
		}
		
		
		
		
	}




?>