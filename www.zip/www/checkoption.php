<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Untitled</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=ABeeZee">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Actor">
    <link rel="stylesheet" href="assets/css/Login-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Profile-Edit-Form.css">
    <link rel="stylesheet" href="assets/css/Profile-Edit-Form.css">
    <link rel="stylesheet" href="assets/css/styles.css">
	
    <link rel="stylesheet" href="assets/allfontasam.css">
</head>

<body style="background-position:center;background-size:cover;background-repeat:no-repeat;background-image:url(&quot;assets/img/BG-01.png&quot;);">
<a href="homepage.php"><button class="btn btn-danger">Back..</button></a>
    <h1 class="text-center" style="margin-top:60px;color:rgb(254,255,255);font-family:Actor, sans-serif;">Student Information</h1>
	
	<hr />
	<hr />
		
	<div class="container">
		<div class="row">
			<div class="col-md-4" id="hoverr">
                    <a href="assignment.php">
                        <img src="assets/img/assignment.jpg" alt="" />
                       
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="exammark.php"><img style="height:220px;width:300px;" src="assets/img/test-paper-img.jpg" alt="" /></a>
                </div>
                <div class="col-md-4">
                    <a href="checkoption.php"><div class="jumbotron" style="background-color:rgba(101,145,190,0.07);">
                        <h1 class="text-center" style="color:rgb(255,255,255);font-family:Actor, sans-serif;">Edit &nbsp;additional Record</h1>
                    </div></a>
                </div>
		
		</div>
	</div>
		
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/MUSA_fullscreen-search.js"></script>
    <script src="assets/js/Profile-Edit-Form.js"></script>
</body>

</html>