<!DOCTYPE html>
<html lang="en">
<head>
  <title>Management Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bs4/bootstrap.min.css">
  <script src="bs4/jquery.min.js"></script>
  <script src="bs4/popper.min.js"></script>
  <script src="bs4/bootstrap.min.js"></script>
  <link rel="stylesheet" href="common.css" />
</head>
<body>

<div class="jumbotron text-center headd" style="height:200px;">
	<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
    Search By Roll
  </button>
	<a href="homepage.php"><input type="submit" class="btn btn-info" style="left:0px;" value="Home" /></a>
  <h1>Welcome to the Coaching management</h1>
  <p>This is the demo of some operation for managing the students of a coaching</p> 
</div>


<div class="modal fade" id="myModal">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Searching By Roll......</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
          <form class="form-inline" action="srcresult.php" method="post">
			<input type="text" class="form-control" name="roll" placeholder="Enter Roll" />
			<input type="submit" class="btn btn-danger" value="Search Now" />
		  </form>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>



  
<div class="container">
`	<div class="row">
		
		<div class="col-md-5 insertlistleft" >
			<h2 style="color:#ff7f50;" id="reco">InserT Stuent Record....</h2>
			<hr style="background:black;padding:1px 0px;" />
			<div class="container formmm">
				<form action="insert.php" method="post" enctype="multipart/form-data">
					<div class="input-group mb-3">
						<div class="input-group-prepend">
						  <span class="input-group-text">Student</span>
						</div>
						<input required name="fname" type="text" class="form-control" placeholder="First Name">
						<input required name="lname" type="text" class="form-control" placeholder="Last Name">
					 </div>
					<div class="form-group">
					  <label for="clss">College/School....</label>
					  <input type="text" name="collegename" class="form-control" id="clss" required placeholder="college or school name">
					</div>
					<div class="form-group">
					  <label for="clsss">Mobile NO....</label>
					  <input type="text" name="smobile" class="form-control" id="clsss" required placeholder="Student mobile">
					</div>
					<div class="form-group">
					  <label for="clssg">Gaurdian mobile....</label>
					  <input type="text" name="Gmobile" class="form-control" id="clssg" required placeholder="Gardian mobile">
					</div>
					
					<div class="input-group mb-3">
						<div class="input-group-prepend">
						  <span class="input-group-text">Student</span>
						</div>
						 <input type="text" name="battch" placeholder="batch name.." class="form-control"/>
						<input required name="broll" type="text" class="form-control" placeholder="Batch Roll">
					</div>
					
					<input type="file" name="image"  />
					<hr />
					<input name="recoddedd" type="submit" value="Add Record" class="form-control btn btn-primary" />
					<hr />
					<hr />
					<hr />
					<hr />
					
					
					
					
				</form>
				
			</div>
				
			
		</div>
		<div class="col-md-7 listdisplay">
			<a href="insert.php"><img id="rot" style="height:30px;width:30px;" src="image/refresh.png" alt="" /></a>
			<table class="table table-dark table-hover">
					<thead>
						<tr>
							<th>Student Name</th>
							<th>College name</th>
							<th>Batch Roll</th>
							<th>Details...</th>
						</tr>
					</thead>
		
			<?php
				$connection=new SQLite3('management.db');
				$sql="select * from studentinfo ORDER BY id DESC";
				$result=$connection->query($sql);
				while($row=$result->fetchArray(SQLITE3_ASSOC))
				{
					$name=$row['fname'].' '.$row['lname'];
					$college=$row['collegename'];
					$broll=$row['broll'];
					$sid=$row['id'];
					?>
					
					<tr>
						<td><?php echo $name;?></td>
						<td><?php echo $college;?></td>
						<td><?php echo $broll;?></td>
						<td><a href="details.php?sid=<?php echo $sid;?>" style="color:red;" >Sell details</a></td>
						
					</tr>
									
				<?php
				}
				?>
			</table>
			
			
		</div>

	</div>
</div>

</body>
</html>


<?php

	$connection=new SQLite3('management.db');
	
	if(isset($_POST['recoddedd']))
	{
		$target="studentimage/".basename($_FILES['image']['name']);
		$fname=$_POST['fname'];
		$lname=$_POST['lname'];
		$collegename=$_POST['collegename'];
		$smobile=$_POST['smobile'];
		$Gmobile=$_POST['Gmobile'];
		$battch=$_POST['battch'];
		$broll=$_POST['broll'];
		$img=$_FILES['image']['name'];
		
		$sql="insert into studentinfo(fname,lname,collegename,smobile,gmobile,battch,broll,image) values('$fname','$lname','$collegename','$smobile','$Gmobile','$battch','$broll','$img')";
		$result=$connection->query($sql);
		if($result)
		{
			if(move_uploaded_file($_FILES['image']['tmp_name'],$target))
				{
					echo ' ';
				}
			echo "<script type='text/javascript'>
				document.getElementById('reco').innerHTML='Recorded Successfully!! Try another..'
			</script>";
		}
		else
		{
			echo "<script type='text/javascript'>
				document.getElementById('reco').innerHTML='Recorded Failed!! Roll already exist...'
			</script>";
		}
		
	}


?>
