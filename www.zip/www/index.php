<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Untitled</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=ABeeZee">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Actor">
    <link rel="stylesheet" href="assets/css/Login-Form-Clean.css">
    <link rel="stylesheet" href="assets/css/Profile-Edit-Form.css">
    <link rel="stylesheet" href="assets/css/Profile-Edit-Form.css">
    <link rel="stylesheet" href="assets/css/styles.css">
	
	<script src="sweetalert2/sweetalert2.min.js"></script>
	<link rel="stylesheet" type="text/css" href="sweetalert2/sweetalert2.css">
</head>

<body style="background-position:center;background-size:cover;background-repeat:no-repeat;background-image:url(&quot;assets/img/BG-01.png&quot;);height:100vh;">
    <div class="login-clean" style="background-color:rgba(241,247,252,0);">
        <form method="post" style="background-color:rgba(66,87,140,0.26);" action="index.php">
            <h2 class="sr-only">Login Form</h2>
            <div class="illustration"><i class="icon ion-ios-contact-outline" style="color:rgb(71,119,244);"></i></div>
            <div class="form-group"><input required class="form-control" type="text" name="email" placeholder="Usename"/></div>
            <div class="form-group"><input required class="form-control" type="password" name="password" placeholder="Password"/></div>
            <div class="form-group"><input class="btn btn-primary btn-block" type="submit" name="subbttttttttttttt" value="Log In" style="background-color:rgb(71,151,244);"/></div><a href="#" class="forgot">Forgot your email or password?</a>
			</form>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/MUSA_fullscreen-search.js"></script>
    <script src="assets/js/Profile-Edit-Form.js"></script>
</body>

</html>


<?php
	$db=$connection=new SQLite3('management.db');
	if(isset($_POST["subbttttttttttttt"]))
	{
		$email=$_POST['email'];
		$password=$_POST['password'];
		
		//$sql="SELECT * FROM admin where email='$email' and password='$password'";
		//$result=$connection->exec($sql);
		if($email=="adilreza043" && $password="12345")
		{
			echo "<script language='javascript'>
				window.location.href='homepage.php';
			</script>";
		}
		else
		{
			echo "<script language='javascript'>
					
					swal(
				  'Sorry!!!',
				  'Admin Not RecogNised....',
				  'error'
				);
					
				</script>";
		}
		
		
	}

?>