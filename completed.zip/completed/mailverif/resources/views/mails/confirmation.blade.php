HI {{$name}}
your registration is completed click the name below...


{{route('confirmation', $token)}}