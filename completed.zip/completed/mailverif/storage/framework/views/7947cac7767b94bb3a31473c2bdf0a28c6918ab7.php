HI <?php echo e($name); ?>

your registration is completed click the name below...


<?php echo e(route('confirmation', $token)); ?>